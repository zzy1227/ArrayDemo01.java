import java.util.Scanner;
public class 张涛姐姐该回复了{
    public static void main(String[] args)
    {
        Scanner z=new Scanner(System.in);
        System.out.println("输入时间：");
        int a=z.nextInt();
        if (a<0||a>=24){
            System.out.println("无法输出");
        }else{if (7>=a||a>=18){
            System.out.println("张涛姐姐该回复学妹了");
        }else{
            System.out.println("张涛姐姐该回复学弟了");
        }}
    }
}

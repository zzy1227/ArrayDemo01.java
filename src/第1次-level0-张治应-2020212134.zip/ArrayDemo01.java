public class ArrayRefDemo01 {
    public static void main(String[] args){
        int score[]={15,25,10,30,40,20,50};
        for(int i=1;i<score.length;i++){
            for(int j=0;j<score.length;j++){
                if(score[i]<score[j]){
                    int temp=score[i];
                    score[i]=score[j];
                    score[j]=temp;
                }
            }
        }
        for(int i=0;i<score.length;i++){
            System.out.print(score.length[i]+"\t");
        }
    }
}
